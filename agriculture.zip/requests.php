<?php
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agricultural Management And Hiring system</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<?php require 'init/navbaradmin.php';?>
<div class="main">

	<section>
		<?php
		if (isset($_GET['deleted'])){
				echo '<span style="color:red">Deleted successful</span><br><br>';
		}

	?>
			<table style="width: 100%!important;">
				<thead style="padding: 20px; background: #ccc; ">
					<tr >
						<td>Tool name</td>
						<td>Too description</td>
						<td>First name</td>
						<td>Last name</td>
						<td>Id number</td>
						<td>Duration</td>
						<td>Date</td>
						<td>Status</td>
					</tr>

				</thead>

				<tbody>
					<?php
			$sql = mysqli_query($data->con,"SELECT hired.id, tools.toolname,tools.description, users.fname,users.lname, users.idno, hired.duration,hired.recdate,hired.status  FROM hired, users, tools WHERE users.id = hired.userid  AND tools.id = hired.toolid ");
			if (mysqli_num_rows($sql) == true){
			while ($fetch = mysqli_fetch_array($sql)){?>
				<tr>
					<td><?php echo ucfirst($fetch['toolname']); ?></td>
					<td><?php echo ucfirst($fetch['description']); ?></td>
					<td><?php echo $fetch['fname']; ?></td>
					<td><?php echo $fetch['lname']; ?></td>
					<td><?php echo $fetch['idno']; ?></td>
					<td><?php echo $fetch['duration'].' days'; ?></td>
					<td><?php echo date('d-m-Y',strtotime($fetch['recdate'])); ?></td>
					<td>
						<?php if ($fetch['status'] == '0')
						{
						 echo '<a href="approve.php?id='.$fetch['id'].'" style="color:red;">Receive payment </a>';
						} else { 
							echo '<span style="color:green;">Approved </span>';
						}
							?>
						</td>						
				</tr>
					<?php	}}else {?>

			<h2 style="color:red;">No records</h2>

			<?php

					}	

		?>
				</tbody>
					
			</table>
		
	</section>

</div>


</body>
</html>