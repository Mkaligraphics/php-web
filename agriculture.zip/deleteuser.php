<?php
require 'init/db.class.php';
$data  =  new dbase();
$id = $_GET['id'];
if (isset($id)){
	if ($data->con->query("DELETE FROM users WHERE id = '$id'")){
			header("location:admin.php?deleted");
	}
	
}


?>