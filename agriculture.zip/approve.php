<?php
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agracultural Management And Hiring system</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<?php require 'init/navbaradmin.php';?>
<div class="main">
		<?php
		if (isset($_GET['id'])){
				$id = $_GET['id'];
				$sql =$data->con->query("SELECT id FROM statement WHERE hiredid = '$id'");
				if (mysqli_num_rows($sql) == true){
					echo '<span style="color:red;">This has already been approved</span>';
					die();
				}
			if ($data->con->query("INSERT INTO statement (hiredid) VALUES('$id')")){
				if ($data->con->query("UPDATE hired SET status='1' WHERE id ='$id' ")){
					echo '<span style="color:green;">You have successful approved</span>';
				}
				
			}
			
		}


		?>


</div>


</body>
</html>