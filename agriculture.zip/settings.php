<?php
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agracultural Management And Hiring system</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<?php require 'init/navbaradmin.php';?>
<div class="main">

	<section >

	<?php 
	if (isset($_GET['failed'])){
		echo '<span style="color:red;">Operation failed, make sure you dont repeat duration</span><br/><br/>';
	}


	if (isset($_POST['submit'])){
		$duration = $_POST['duration'];
		$amount = $_POST['amount'];
		$toolid = $_GET['tool'];

	if (empty($_POST['amount']) || empty($_POST['duration'])){
			echo '<script>alert("Empty array!")</script>';

	}

		for ($i=0; $i<count($duration); $i++){
$qr= $data->con->query("SELECT id FROM costings WHERE toolid = '$toolid' AND duration = '$duration[$i]'");
if (mysqli_num_rows($qr) == false ){		

		if ($data->con->query("INSERT INTO costings (duration, toolid, amount) VALUES ('$duration[$i]','$toolid','$amount[$i]')")){
			echo '<span style="color:green;">You have successful added new features</span><br><br>';
		}
} else {
	header('location:settings.php?failed');
}
		
		}
		

	}


	?>
	<form method="POST">

			<table style="width: 100%;">
				<thead style="padding: 20px; background: #ccc;">
					<tr >
						<td>Choose</td>
						<td>Days</td>
						<td>Amount</td>
					</tr>
				</thead>
				<tbody>
					
				<tr>
					<td><input type="checkbox" name="duration[]" value="10"></td>
					<td>10</td>
					<td><input type="text" name="amount[]"></td>
										
				</tr>

				<tr>
					<td><input type="checkbox" name="duration[]" value="20"></td>
					<td>20</td>
					<td><input type="text" name="amount[]"></td>
										
				</tr>

				<tr>
					<td><input type="checkbox" name="duration[]" value="30"></td>
					<td>30</td>
					<td><input type="text" name="amount[]"></td>
										
				</tr>

				<tr>
					<td><input type="checkbox" name="duration[]" value="40"></td>
					<td>40</td>
					<td><input type="text" name="amount[]"></td>
										
				</tr>

				<tr>
					<td><input type="checkbox" name="duration[]" value="50"></td>
					<td>50</td>
					<td><input type="text" name="amount[]"></td>
										
				</tr>
				
				</tbody>
				
			</table>
						<input type="submit" name="submit" value="Save record">

	</form>		
	</section>

	


</body>
</html>