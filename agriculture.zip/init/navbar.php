<div class="topnav">
  <a class="active" href="dashboard.php">Home</a>
  <a href="hired.php">Hired tools</a>
  <a href="returnedtools.php">Returned tools</a>
  <a href="mystatement.php">Statement</a>

		 <div class="dropdown" style="float:right; ">
		  <a href="#" class="dropbtn">	<?php 
		  	if ($core->loggedin()){
		  		 echo strtoupper($core->getfield('fname')).' '.strtoupper($core->getfield('lname'));
		  	} else 	{
		  		header('location:index.php');
		  	}	 
		   ?>
		  </a>	
		  <a href="logout.php"><img src="imgs/logout.png" style="width: 0.8em;" /> Logout</a>

		</div> 
</div> 
