<?php

class core extends dbase{
	function loggedin() {
		if (isset($_SESSION['id']) && !empty($_SESSION['id'])){
			return true;
		}else {
			return false;
		}

	}

	//getting users fields
	function getfield($fields){
		$result = $this->con->query ("SELECT $fields FROM users WHERE id = '".$_SESSION['id']."' ") ;
		   $counts =  $result ->num_rows;
		   if ($counts > 0){
		   	while ($rw = mysqli_fetch_assoc($result)){
		  return $rw[$fields];
		   	}
	   }
	}


}






?>