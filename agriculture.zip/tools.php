<?php
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agracultural Management And Hiring system</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<?php require 'init/navbaradmin.php';?>
<div class="main">

	<section class="toolstable" style="width: 800px;">

	<?php
	

			$sql = mysqli_query($data->con,"SELECT * FROM tools WHERE status = '0'  ");
			if (mysqli_num_rows($sql) == true){
			while ($fetch = mysqli_fetch_array($sql)){?>
<div class="gallery">
				<img style="width: 250px; height: 150px;" src="tools/<?php echo $fetch['upload']; ?>">
				<p><?php echo $fetch['description']; ?></p>
				
				<p><a href="settings.php?tool=<?php echo $fetch['id']; ?>"><button id="<?php echo $fetch['id']; ?>" class="hireme" >Settings</button></a></p>
</div>
		<?php	}}else {?>
			<h2 style="color:red;">No records</h2>
		<?php
			}
		?>	
	</section>


	<section class="newtools">


<?php		
if (isset($_GET['success'])){
		echo '<span style="color:green;">New tool added successful</span>';
	}
		$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); 
$path = 'tools/'; 


if(isset($_POST['submit'])){


	$img = $_FILES['photo']['name']; 
	$tmp = $_FILES['photo']['tmp_name'];
	

	// get uploaded file's extension
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));	
	// can upload same image using rand function
	$final_image = strtolower(rand(1000,1000000).$img);
	$final_image = str_replace(' ', '_', $final_image);	

	// check's valid format
	if(in_array($ext, $valid_extensions)) 
	{					
		$path = $path.strtolower($final_image);	

		$select = $data->con->query("SELECT id FROM tools WHERE description = '".$_POST['description']."'");
		if (mysqli_num_rows($select) == true){
			echo '<span class="text-danger">This agriculture tool exists!</span>';
			exit(0);
		}
			
		if(move_uploaded_file($tmp,$path)) 
		{
			
		$toolname = $_POST['toolname'];
    	$description = $_POST['description'];
    	    

    
   if ($data->con->query("INSERT INTO tools (toolname, description, upload) VALUES ('$toolname','$description','$final_image')")){

header("location:tools.php?success");

   } else {

   	echo '<span style="color:red;">Error, please try again</span>';
   }
    
   
		}
	} 
	else 
	{
		echo '<span style="color:red;">Invalid image{<em>*</em>}</span>';
	}
} 
?>
		<form method="POST" enctype="multipart/form-data">
			<label>Tool name</label>
			<input type="text" name="toolname" value="<?php if(isset($_POST['toolname'])){ echo $_POST['toolname']; } ?>" required> <br><br>

			<input type="file" class="custom-file-input" id="customFile" name="photo">
			 <br><br>


			<textarea name="description" placeholder="Write description"></textarea>
			


			
			<input type="submit" name="submit" value="Save record">
			


		</form>	
		
	</section>

</div>


</body>
</html>