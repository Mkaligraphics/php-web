<?php
session_start();
$id = $_SESSION['id'];
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Agricultural Management And Hiring system</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php require 'init/navbar.php'; ?>

<div class="main">
<h2>My statements</h2>
	<table style="width:100%;">
			<thead>
				<tr style="background: green; color: #fff; font-weight: bolder;">
					<td>Date</td>
					<td>Tool</td>
					<td>Duration</td>
					<td>Amount</td>				
				</tr>
			</thead>
		<tbody>
			<?php
			$total = 0;
			$sql = mysqli_query($data->con,"SELECT tools.toolname,hired.duration, hired.amount, statement.recdate FROM hired, tools, statement WHERE tools.id = hired.toolid AND hired.userid = '$id' AND hired.id = statement.hiredid ");
			if (mysqli_num_rows($sql) == true){
			while ($fetch = mysqli_fetch_array($sql)){ $total = $total + $fetch['amount'];?>
				<tr>
					<td><?php echo date('d-m-Y',strtotime($fetch['recdate'])); ?></td>
					<td><?php echo ucfirst($fetch['toolname']); ?></td>					
					<td><?php echo $fetch['duration']; ?></td>
					<td><?php echo $fetch['amount']; ?></td>					
				</tr>
			<?php
		}}else {?><tr>
			<td colspan="5" style="color: red;">No records</td>
			</tr>
			<?php
}
			?>
			<tr style="font-weight: bolder;color: red;">
				<td colspan="2"></td>				
				<td>Total</td>
				<td><?php echo number_format($total,2); ?></td>
			</tr>
		
		</tbody>
		

	</table>

	

	
</div>
  <script src="js/jquery-1.11.1.js"></script>
  <script src="js/custom.js"></script>

</body>
</html>