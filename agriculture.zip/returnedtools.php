<?php
session_start();
$id = $_SESSION['id'];
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Agricultural Management And Hiring system</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php require 'init/navbar.php'; ?>

<div class="main">
<h2>Returned equipments</h2>
	<table style="width:100%;">
			<thead>
				<tr style="background: green; color: #fff; font-weight: bolder;">
					<td>Date</td>
					<td>Tool</td>					
					<td>Duration</td>
					<td>Status</td>	
					<td>Amount</td>	
				</tr>
			</thead>
		<tbody>
			<?php
			$sql = mysqli_query($data->con,"SELECT tools.toolname,hired.duration, hired.amount, hired.status,hired.recdate FROM hired, tools  WHERE tools.id = hired.toolid AND hired.userid = '$id' AND hired.returned = '1' ");
			if (mysqli_num_rows($sql) == true){
			while ($fetch = mysqli_fetch_array($sql)){?>
				<tr>
					<td><?php echo date('d-m-Y',strtotime($fetch['recdate'])); ?></td>
					<td><?php echo ucfirst($fetch['toolname']); ?></td>					
					<td><?php echo $fetch['duration']; ?></td>
					<td><span style="color:green;">Returned </span></td>	
					<td><?php echo $fetch['amount']; ?></td>				
					
				</tr>
			<?php
		}}else {?><tr>
			<td colspan="5" style="color: red;">No records</td>
			</tr>
			<?php
}
			?>
		
		</tbody>
		

	</table>

	

	
</div>
  <script src="js/jquery-1.11.1.js"></script>
  <script src="js/custom.js"></script>

</body>
</html>