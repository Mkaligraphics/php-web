<?php
session_start();
require '../init/db.class.php';
$data  =  new dbase();

$sql = $data->con->query("SELECT * FROM costings WHERE toolid = '".$_POST['thisId']."' AND duration  = '".$_POST['duration']."' ");
if (mysqli_num_rows($sql) == true){
while ($rw = mysqli_fetch_array($sql)){
			echo json_encode($rw['amount']);
	}

} else {
	echo json_encode("Not available");
}
	


?>