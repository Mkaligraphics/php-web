$(document).ready(function(){




});
$(document).on('change','.duration',function(){
		let thisId = $(this).attr('id');
		let duration = $(this).val();

	$.ajax({
			url:'harvest/costings.php',
			method:'POST',
			dataType: "json",
			data:{thisId:thisId, duration:duration},
			success:function(feedback){
				$('.cost'+ thisId).html(feedback);	
				$("#toolid"+thisId).val(feedback);
				$("#amount"+thisId).val(feedback);			
			}
	})
})	

$(document).on('click','.hireme',function(){
			let me = $(this).attr("id");
			let duration = $(".duration").val();
			let confrm = confirm("Are you sure to hire this?");
			let amount = $("#amount"+me).val();
			
			if (confrm == true){
				if ($("#toolid"+me).val() == "Not available" || $("#toolid"+me).val()==0){
					alert("The service selected is unavailable");
					return false;
				}else {
						$.ajax({
							url:'process/hire.php',
							method:'POST',
							data:{me:me, duration:duration,amount:amount},
							success:function(feedback){
									if (feedback == 0){
										alert("Process unsessccesful");
									} else {
										alert("This tool is preserved for you for 24 for payment!");
										location.reload();
									}
											
							}
					})
				}
				
			}
			
});