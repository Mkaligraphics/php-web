<?php
session_start();
$id = $_SESSION['id'];
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Agracultural Management And Hiring system</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php require 'init/navbar.php'; ?>

	
<div class="main">

<h2>Hired tools</h2>
	<table style="width:100%;">
			<thead>
				<tr style="background: green; color: #fff; font-weight: bolder;">
					<td>Tool</td>
					<td>Amount</td>					
					<td>Duration</td>
					<td>Date</td>
					<td>Status</td>
				</tr>
			</thead>
		<tbody>
			<?php
			$sql = mysqli_query($data->con,"SELECT tools.toolname,hired.duration, hired.status, hired.amount, hired.recdate FROM hired, tools WHERE tools.id = hired.toolid AND hired.userid = '$id'  ");
			if (mysqli_num_rows($sql) == true){
			while ($fetch = mysqli_fetch_array($sql)){?>
				<tr>
					<td><?php echo ucfirst($fetch['toolname']); ?></td>
					<td><?php echo $fetch['amount']; ?></td>					
					<td><?php echo $fetch['duration']; ?></td>
					<td><?php echo date('d-m-Y',strtotime($fetch['recdate'])); ?></td>
					<td><?php if ($fetch['status']=='0'){ echo '<span style="color:brown;">Pending</span>';}else{ echo '<span style="color:green;">Paid</span>'; } ?></td>
				</tr>
			<?php
		}}else {?><tr>
			<td colspan="5" style="color: red;">No records</td>
			</tr>
			<?php
}
			?>
		
		</tbody>
		

	</table>

	

	
</div>
  <script src="js/jquery-1.11.1.js"></script>
  <script src="js/custom.js"></script>

</body>
</html>