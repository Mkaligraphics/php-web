<?php
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agracultural Management And Hiring system</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>

<?php require 'init/navbaradmin.php';?>

<div class="main">

	
	<section class="newtools">

		<?php if (isset($_POST['submit'])){// post array
		
			$fname = $_POST['fname'];
			$lname = $_POST['lname'];
			$idno = $_POST['idno'];
			$phone = $_POST['phone'];
			$email = $_POST['email'];
			$location = $_POST['location'];


$select =  $data->con->query("SELECT id FROM users WHERE idno = '$idno' ");
if (mysqli_num_rows($select) > 1){
	echo "<span style='color:red;'>This user has already registered</span>";
} else {


if ($data->con->query("UPDATE users SET fname = '$fname',lname='$lname',idno='$idno',email='$email',phone='$phone',location='$location' WHERE id = '".$_GET['id']."' ")){

	echo '<span style="color:green;">Farmer updated successful <a href="admin.php">Home</a></span>';
}


	}
		}
?>

<?php 
if (isset($_GET['id'])){
	$qry = $data->con->query("SELECT * FROM users WHERE id = '".$_GET['id']."'");
	while ($rw = mysqli_fetch_array($qry)){ ?>
		<form method="POST">
			<label>First name</label>
			<input type="text" name="fname" value="<?php echo $rw['fname'];?>" required> <br><br>

			<label>Last name</label>
			<input type="text" name="lname" required="required" value="<?php echo $rw['lname'];?>" > <br><br>

			<label>Id number</label>
			<input type="text" name="idno" value="<?php echo $rw['idno'];?>" > <br><br>

			<label>Email</label>
			<input type="email" name="email" value="<?php echo $rw['email'];?>"  required="required"> <br><br>

			<label>Phone</label>
			<input type="text" name="phone" required="required" value="<?php echo $rw['phone'];?>" > <br><br>

			<label>Location</label>
			<input type="text" name="location" value="<?php echo $rw['location'];?>"  required="required"> <br><br>
			
			<input type="submit" name="submit" value="Edit user">
			


		</form>	
	<?php }} ?>	
	</section>

</div>


</body>
</html>