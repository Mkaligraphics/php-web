<?php

session_start();
require '../init/db.class.php';
$data  =  new dbase();
$id = $_SESSION['id'];
$toolid = $_POST['me'];
$duration = $_POST['duration'];
$amount = $_POST['amount']; 

if ($data->con->query("INSERT INTO hired (toolid,userid,duration,amount) VALUES ('$toolid', '$id','$duration','$amount') ")){
	if ($data->con->query("UPDATE tools SET status = '1' WHERE id = '$toolid'")){

		echo 1;
	}
} else {
	echo 0;
}
?>