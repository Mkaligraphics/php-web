# AGRICULTURE MANAGEMENT AND HIRING SYSTEM

visit- https://github.com/Mkaligraphics/php-web/

How To Install -
---------

1. Create Database amhs.
2. Run import.sql script provided in sql folder.
3. Go to browser, type: http://localhost/amhs

---------
Available credentials are:
1. Admin	- username: 12345678, password: 1234
2. farmer1	- username: 12345677, password: 1234
3. farmer2	- username: 54677738, password: 1234


Note -
---------
1. This is not ready for PRODUCTION.
2. The username and password of sample users are stored in table `users`.



