<?php
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Agracultural Management And Hiring system</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php require 'init/navbar.php'; ?>


	
<div class="main">

			<?php

			$sql = mysqli_query($data->con,"SELECT * FROM tools WHERE status = '0'  ");
			if (mysqli_num_rows($sql) == true){
			while ($fetch = mysqli_fetch_array($sql)){?>
<div class="gallery">
				<img style="width: 250px; height: 150px;" src="tools/<?php echo $fetch['upload']; ?>">
				<p><?php echo $fetch['description']; ?></p>
				<p>
					<select name="duration" id="<?php echo $fetch['id']; ?>" class="duration">
						<option value="0">Select day</option>
						<option value="10">10 days</option>
						<option value="20">20 days</option>
						<option value="30">30 days</option>
						<option value="40">40 days</option>
						<option value="50">50 days</option>
					</select>
				</p>
				<p style="color: blue;"> <span class="cost<?php echo $fetch['id']; ?>">0</span></p>

			<input type="hidden"  id="toolid<?php echo $fetch['id']; ?>">
			<input type="hidden"  id="amount<?php echo $fetch['id']; ?>">

			<p><button id="<?php echo $fetch['id']; ?>" class="hireme" >Hire</button></p>
</div>
		<?php	}}else {?>
			<h2 style="color:red;">No records</h2>
		<?php
			}
		?>	
</div>

  <script src="js/jquery-1.11.1.js"></script>
  <script src="js/custom.js"></script>

</body>
</html>