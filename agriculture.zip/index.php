<?php
session_start();
require 'init/db.class.php';
$data = new dbase();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agricultural Management And Hiring system</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/login.css">

</head>
<body>



<div class="login">
	


	 <form  method="post">
  <div class="imgcontainer">
    <img src="imgs/logo.png" alt="Avatar" class="avatar">
  </div>


	<?php
	if (isset($_POST['submit'])){// post array
		if (!empty($_POST['username']) && !empty($_POST['password'])){ //if empty
			$username = $_POST['username'];
			$password = md5($_POST['password']) ;

			$user = $data->con->query("SELECT * FROM users WHERE idno = '$username' AND password = '$password'");
			if (mysqli_num_rows($user)> 0 ){
					$identity = mysqli_fetch_array($user);
					$id = $identity['id']; 	
					$_SESSION['id']= $id;

					switch ($identity['level']) {
						case 'admin':
							header('location:admin.php');
							break;
						
						default:
							header('location:dashboard.php');
							break;
					}

					
			} else {
				echo '<span style="padding-left:1em; color:red">Authentification failed</span>';
			}

		
	} else {
		echo 'All fields are required';
	}
}// end of post arrya
	?>
  <div class="container">
    <input type="text" placeholder="Enter Username"  name="username" required>

    <input type="password" placeholder="Enter Password" name="password" required>

    <button type="submit" name="submit">Login</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <a href="index.php"><button type="button" class="cancelbtn">Cancel</button></a>
    <span class="psw"><a href="register.php">Registere ?</a></span>
  </div>
</form> 
</div>	

</body>
</html>