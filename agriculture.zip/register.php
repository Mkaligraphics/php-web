<?php
session_start();
require 'init/db.class.php';
$data = new dbase();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agracultural Management And Hiring system</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<a href="index.php">Back to login pager</a>
<br><br>


<div style="width: 50%; margin: auto;">	

<?php if (isset($_POST['submit'])){// post array
		
			$fname = $_POST['fname'];
			$lname = $_POST['lname'];
			$idno = $_POST['idno'];
			$phone = $_POST['phone'];
			$email = $_POST['email'];
			$location = $_POST['location'];
			$password = md5($_POST['password']);
if ($_POST['password'] != $_POST['confirm']){

	echo 'The two passwords do not match';
} else {
$select =  $data->con->query("SELECT id FROM users WHERE idno = '$idno' ");
if (mysqli_num_rows($select) == true){
	echo "This user has already registered";
} else {


if ($data->con->query("INSERT INTO users (fname,lname,idno,email,phone,location, password) VALUES ('$fname', '$lname','$idno','$email','$phone', '$location', '$password') ")){

	echo '<span style="color:green">Farmer is successful registered</span> <a href="index.php">Login</a>';
}

}
}
}
?>
		<form method="POST">
			<label>First name</label>
			<input type="text" name="fname" value="<?php if(isset($_POST['fname'])){ echo $_POST['fname']; } ?>" required> <br><br>

			<label>Last name</label>
			<input type="text" name="lname" required="required" value="<?php if(isset($_POST['lname'])){ echo $_POST['lname']; } ?>" > <br><br>

			<label>Id number</label>
			<input type="text" name="idno" value="<?php if(isset($_POST['idno'])){ echo $_POST['idno']; } ?>" > <br><br>

			<label>Email</label>
			<input type="email" name="email" value="<?php if(isset($_POST['email'])){ echo $_POST['email']; } ?>"  required="required"> <br><br>

			<label>Phone</label>
			<input type="text" name="phone" required="required" value="<?php if(isset($_POST['phone'])){ echo $_POST['phone']; } ?>" > <br><br>

			<label>Location</label>
			<input type="text" name="location" value="<?php if(isset($_POST['location'])){ echo $_POST['location']; } ?>"  required="required"> <br><br>

			<label>Passwrod</label>
			<input type="password" name="password" required="required"> <br><br>

			<label>Confirm passwrod</label>
			<input type="password" name="confirm"> <br><br>
			
			<input type="submit" name="submit" value="Register">		


		</form>	

</div>

</body>
</html>