<?php
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agracultural Management And Hiring system</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<?php require 'init/navbaradmin.php';?>
<div class="main">

	<section class="toolstable">
		<?php
		if (isset($_GET['deleted'])){
				echo '<span style="color:red">Deleted successful</span><br><br>';
		}

	?>
			<table>
				<thead style="padding: 20px; background: #ccc;">
					<tr >
						<td>First name</td>
						<td>Last name</td>
						<td>Id number</td>
						<td>Email</td>
						<td>Phone</td>
						<td>Location</td>
						<td>Action</td>
					</tr>

				</thead>

				<tbody>
					<?php
			$sql = mysqli_query($data->con,"SELECT * FROM users WHERE level != 'admin'  ");
			if (mysqli_num_rows($sql) == true){
			while ($fetch = mysqli_fetch_array($sql)){?>
				<tr>
					<td><?php echo ucfirst($fetch['fname']); ?></td>
					<td><?php echo  ucfirst($fetch['lname']); ?></td>
					<td><?php echo $fetch['idno']; ?></td>
					<td><?php echo $fetch['email']; ?></td>
					<td><?php echo $fetch['phone']; ?></td>
					<td><?php echo $fetch['location']; ?></td>
					<td><a href="edituser.php?id=<?php  echo $fetch['id']; ?>">Edit</a>
					<a href="deleteuser.php?id=<?php  echo $fetch['id']; ?>">Delete</a></td>						
				</tr>
					<?php	}}else {?>

			<h2 style="color:red;">No records</h2>

			<?php

					}	

		?>
				</tbody>
					
			</table>
		
	</section>

	<section class="newtools">

		<?php if (isset($_POST['submit'])){// post array
		
			$fname = $_POST['fname'];
			$lname = $_POST['lname'];
			$idno = $_POST['idno'];
			$phone = $_POST['phone'];
			$email = $_POST['email'];
			$location = $_POST['location'];
			$password = md5($_POST['password']);
if ($_POST['password'] != $_POST['confirm']){

	echo 'The two passwords do not match';
} else {
$select =  $data->con->query("SELECT id FROM users WHERE idno = '$idno' ");
if (mysqli_num_rows($select) == true){
	echo "<span style='color:red;'>This user has already registered</span>";
} else {


if ($data->con->query("INSERT INTO users (fname,lname,idno,email,phone,location, password) VALUES ('$fname', '$lname','$idno','$email','$phone', '$location', '$password') ")){

	echo '<span style="color:green;">Farmer is successful registered </span>';
}

}
}
}
?>
		<form method="POST">
			<label>First name</label>
			<input type="text" name="fname" value="<?php if(isset($_POST['fname'])){ echo $_POST['fname']; } ?>" required> <br><br>

			<label>Last name</label>
			<input type="text" name="lname" required="required" value="<?php if(isset($_POST['lname'])){ echo $_POST['lname']; } ?>" > <br><br>

			<label>Id number</label>
			<input type="text" name="idno" value="<?php if(isset($_POST['idno'])){ echo $_POST['idno']; } ?>" > <br><br>

			<label>Email</label>
			<input type="email" name="email" value="<?php if(isset($_POST['email'])){ echo $_POST['email']; } ?>"  required="required"> <br><br>

			<label>Phone</label>
			<input type="text" name="phone" required="required" value="<?php if(isset($_POST['phone'])){ echo $_POST['phone']; } ?>" > <br><br>

			<label>Location</label>
			<input type="text" name="location" value="<?php if(isset($_POST['location'])){ echo $_POST['location']; } ?>"  required="required"> <br><br>

			<label>Passwrod</label>
			<input type="password" name="password" required="required"> <br><br>

			<label>Confirm passwrod</label>
			<input type="password" name="confirm"> <br><br>
			
			<input type="submit" name="submit" value="Register">
			


		</form>	
		
	</section>

</div>


</body>
</html>