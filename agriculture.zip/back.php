<?php
require 'init/db.class.php';
$data = new dbase();


if(isset($_GET['id'])){
		if ($data->con->query("UPDATE hired SET returned = '1' WHERE id = '".$_GET['id']."'")){
			$data->con->query("UPDATE tools SET status = '0' WHERE id = '".$_GET['id']."'");
			header("location:receive.php?backed");
		}
}


?>